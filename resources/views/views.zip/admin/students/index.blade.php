@extends('admin.app')
 
@section('title') {{ $pageTitle }} @endsection
 
@section('content')
<style scoped> .pagination { justify-content: flex-end!important; } </style>
<link rel="stylesheet" href="{{asset('backend/css/lightbox-popup.css')}}">
     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800"><i class="fa fa-users"></i> {{ $pageTitle }}</h1>
        </div>
        <div>
        <a href="{{ route('admin.students.create') }}" class="btn btn-primary pull-right">Add Students</a>
        <a href="{{ route('admin.students.index') }}" class="btn btn-success pull-right">All Students</a>
        </div>
    </div>
    <div id="flash_message"></div>
    @include('admin.partials.flash')
    <div class="row">
        <div class="col-md-12">
           
            <div class="tile">
                <form action="">
                    <div class="row">
                        <div class="col-12 col-md-6 offset-md-6">
                            <div class="form-group d-flex">
                                <input type="text" name="q" placeholder="Enter Student name or mobile Number" class="form-control"/>
                                <input type="submit" class="btn btn-primary" value="Search"/>
                            </div>
                        </div>
                    </div>
                    
                </form>
                <div class="tile-body overflow-auto">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th> # </th>
                                <th> Image </th>
                                <th> Students name </th>
                                <th> Batch No </th>
                                <th> Course Name </th>
                                <th> Status </th>
                                <th> Total Pay </th>
                                <th> Total Due </th>
                                <th> Admission Date</th>
                                <th> Last Update </th>
                                <th style="width:100px; min-width:100px;" class="text-center text-danger"><i class="fa fa-bolt"> </i></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($students as $course)
                                    <tr>
                                        <td>{{ $loop->index+1 }}</td>
                                        <td>
                                            @if($course->image != "")
                                            <div class="popup-gallery">
                                                <a href="{!! asset('public/storage/'.$course->image) !!}" title="{{ $course->sname }}">
                                                    <img src="{!! asset('public/storage/'.$course->image) !!}" alt="!"  height="70">
                                                </a>
                                            </div>
                                            @else
                                                no image
                                            @endif
                                        </td>
                                        <td>{{ $course->sname }} </td>
                                        <td>
                                        @php
                                        $batchno = DB::table('batchs')->where('id',$course->batch_id)->pluck('batchnum')->first();
                                        @endphp
                                        {{$batchno}}
                                        </td>
                                        <td>
                                        @php
                                        $coursename = DB::table('courses')->where('id',$course->course_id)->pluck('name')->first();
                                        @endphp
                                        {{$coursename}}
                                        </td>
                                        <td>
                                            @php
                                            if($course->IsActive == 1){
                                                $status = "<span class='text-success'>Regular</span>";
                                            }
                                            elseif($course->IsActive == 2){
                                                $status = "<span class='text-info'>Iregular</span>";
                                            }
                                            elseif($course->IsActive == 3){
                                                $status = "<span class='text-primary'>Complete</span>";
                                            }
                                            elseif($course->IsActive == 4){
                                                $status = "<span class='text-danger'>Restricted</span>";
                                            }
                                            elseif($course->IsActive == 5){
                                                $status = "<span class='text-warning'>Postponded</span>";
                                            }
                                            @endphp
                                            <b>{!! $status !!}</b>
                                        </td>
                                        <td>
                                            @php
                                            $pay = DB::table('fees_transections')->where('student_id',$course->id)->where('paymentType',1)->sum('paidamount');
                                            @endphp
                                           <span class="text-success"> {{number_format($pay,2)}}</span>
                                        </td>
                                        <td>
                                            @php
                                            $due = $course->balance - $pay;
                                           @endphp
                                          <b class="text-danger">{{number_format($due,2)}}</b> 
                                        </td>
                                        <td>
                                        @php
                                            $date = strtotime($course->admission_date);
                                            $createDate = date('d-M-y', $date);
                                        @endphp
                                            {{ $createDate }}
                                    </td>
                                        <td>
                                        @php
                                            $date = strtotime($course->updated_at);
                                            $updateDate = date('d-M-y', $date);
                                        @endphp    
                                        {{ $updateDate }}
                                    </td>
                                       
                                        <td class="text-center">
                                            <div class="btn-group" role="group" aria-label="Second group">
                                                <div class="dropdown">
                                                    <a href="#" class="btn btn-sm btn-primary dropdown-toggle" id="sms-menu" data-toggle="dropdown"><i class="fas fa-envelope"></i> </a>
                                                    <div class="dropdown-menu" aria-labelledby="#sms-menu">
                                                        <a href="javascript:void(0)" id="dueSms" data-id="{{ $course->id }}" value="{{ $course->id }}" class="dropdown-item" title="Send Due SMS">Due Remainder</a>
                                                        <a href="javascript:void(0)" id="remainderSms" data-id="{{ $course->id }}" value="{{ $course->id }}" class="dropdown-item" title="Class Remainder">Today Class Remainder</a>
                                                        <a href="javascript:void(0)" id="scheduleSms" data-id="{{ $course->id }}" value="{{ $course->id }}" class="dropdown-item" title="New Class Schedule">New Schedule Remainder</a>
                                                        <a href="javascript:void(0)" id="postpondSms" data-id="{{ $course->id }}" value="{{ $course->id }}" class="dropdown-item" title="Today Class Postponded">Today Postpond Remainder</a>
                                                        <a href="javascript:void(0)" id="TomorrowpostpondSms" data-id="{{ $course->id }}" value="{{ $course->id }}" class="dropdown-item" title="Tomorrow Class Postponded">Tomorrow Postpond Remainder</a>
                                                    </div>
                                                </div>
                                                <a href="{{ route('admin.students.view', $course->id) }}" class="btn btn-sm btn-info" title="View Student"><i class="fa fa-eye"></i></a>
                                                @if($course->IsRegister == 1)
                                                <a href="{{ route('admin.registration.create', $course->id) }}" class="btn btn-sm btn-warning text-danger" title="Make Registration"><i class="fa fa-certificate"></i></a>
                                                @endif
                                                <a href="{{ route('admin.students.edit', $course->id) }}" class="btn btn-sm btn-primary" title="Edit Student Information"><i class="fa fa-edit"></i></a>
                                               
                                                <a href="#" class="btn btn-sm btn-danger deletestudents" data-toggle="modal" data-target="#deleteStudent" title="Delete Student Information" id="{{ route('admin.students.delete', $course->id) }}"><i class="fa fa-trash"></i></a>
                                                {{-- <a class="dropdown-item" href="#{{ route('admin.students.delete', $course->id) }}" data-toggle="modal" data-target="#logoutModal">
                                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                                    Logout
                                                </a> --}}
                                            </div>
                                        </td>
                                    </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{ $students->links() }}
                </div>
            </div>
        </div>
    </div>
    <!-- Logout Modal-->
<div class="modal fade" id="deleteStudent" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Are You Sure?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">Click "Delete" below if you are Delete.</div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" id="deleteBtns">Delete</a>
        </div>
    </div>
</div>
</div>
@endsection
@push('scripts')
    <script type="text/javascript" src="{{ asset('backend/js/custom.js') }}"></script> 
    <script type="text/javascript" src="{{ asset('backend/vendor/datatables/jquery.dataTables.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('backend/vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
   <script type="text/javascript">$('#sampleTable').DataTable({order: [[0, 'asc']],});</script>
   <script type="text/javascript" src="{{asset('backend/js/lightbox-popup.min.js')}}"></script>
 
 <script>
    var da;
$('.deletestudents').click(function(){
    da = $(this).attr('id');
    $("#deleteBtns").attr('href', da);
    
});

$(document).ready(function() {

	$('.popup-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-img-mobile',
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1] // Will preload 0 - before current, and 1 after the current image
		},
		image: {
			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
			titleSrc: function(item) {
				return item.el.attr('title');
			}
		}
	});
});
 </script>
@endpush