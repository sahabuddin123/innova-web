<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('admin.dashboard') }}">
        <div class="sidebar-brand-text mx-3"><img src="{{ asset('public/storage/' . config('settings.site_logo')) }}"
                alt="!" height="50"></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link {{ Route::currentRouteName() == 'admin.dashboard' ? 'active' : '' }}"
            href="{{ route('admin.dashboard') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Admins Management
    </div>
    <li class="nav-item @if (Route::currentRouteName() == 'admin.admins.index' ||
            Route::currentRouteName() == 'admin.roles.index' ||
            Route::currentRouteName() == 'admin.shareholder.index' ||
            Route::currentRouteName() == 'admin.investment.index') active @endif">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#admins" aria-expanded="true"
            aria-controls="admins">
            <i class="fas fa-fw fa-users"></i>
            <span>Admins</span>
        </a>
        <div id="admins" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.admins.index') active @endif"
                    href="{{ route('admin.admins.index') }}">All Admin</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.roles.index') active @endif"
                    href="{{ route('admin.roles.index') }}">All Role</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.shareholder.index') active @endif"
                    href="{{ route('admin.shareholder.index') }}">All Investor</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.investment.index') active @endif"
                    href="{{ route('admin.investment.index') }}">Investment Logs</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.investment.withdraw.index') active @endif"
                    href="{{ route('admin.investment.withdraw.index') }}">Investment Withdraws</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.dividend.withdraw.index') active @endif"
                    href="{{ route('admin.dividend.withdraw.index') }}">Dividend Withdraws</a>
            </div>
        </div>
    </li>
    <li class="nav-item @if (Route::currentRouteName() == 'admin.users.index') active @endif">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#users" aria-expanded="true"
            aria-controls="users">
            <i class="fas fa-fw fa-user"></i>
            <span>Users</span>
        </a>
        <div id="users" class="collapse" aria-labelledby="headingTwoOne" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.users.index') active @endif"
                    href="{{ route('admin.users.index') }}">All Users</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.users.create') active @endif"
                    href="{{ route('admin.users.create') }}">Create Users</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Course
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCourseCategory"
            aria-expanded="true" aria-controls="collapseCourseCategory">
            <i class="fas fa-fw fa-book-open"></i>
            <span>Course Category</span>
        </a>
        
        <div id="collapseCourseCategory" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.coursecatg.index') }}">All Courses Category</a>
                <a class="collapse-item" href="{{ route('admin.coursecatg.create') }}">Create Course Category</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-book-open"></i>
            <span>Courses</span>
        </a>
        
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.courses.index') }}">All Courses</a>
                <a class="collapse-item" href="{{ route('admin.courses.create') }}">Create Course</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Batchs
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
            aria-expanded="true" aria-controls="collapseThree">
            <i class="fas fa-fw fa-book-open"></i>
            <span>Batchs</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.batchs.index') }}">All Batchs</a>
                <a class="collapse-item" href="{{ route('admin.batchs.create') }}">Create Batchs</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Admission
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
            aria-expanded="true" aria-controls="collapseFour">
            <i class="fas fa-fw fa-users"></i>
            <span>Students</span>
        </a>
        <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.students.index') }}">All Students</a>
                <a class="collapse-item" href="{{ route('admin.students.create') }}">Add Students</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour2"
            aria-expanded="true" aria-controls="collapseFour2">
            <i class="fas fa-ticket-alt"></i>
            <span>Online Admission</span>
        </a>
        <div id="collapseFour2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.admission.index') }}">All Online Admission</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        BTEB Registration
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
            aria-expanded="true" aria-controls="collapseSix">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Session</span>
        </a>
        <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.session.index') }}">All Session</a>
                <a class="collapse-item" href="{{ route('admin.session.create') }}">Create Session</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
            aria-expanded="true" aria-controls="collapseSeven">
            <i class="fas fa-fw fa-registered"></i>
            <span>Registration</span>
        </a>
        <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.registration.index') }}">All Register Students</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCertificate"
            aria-expanded="true" aria-controls="collapseCertificate">
            <i class="fas fa-fw fa-certificate"></i>
            <span>BTEB Certificate</span>
        </a>
        <div id="collapseCertificate" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.certificate.index') }}">All BTEB Certificate</a>
            </div>
        </div>
    </li>
         <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#icbdcertificate"
            aria-expanded="true" aria-controls="icbdcertificate">
            <i class="fas fa-fw fa-certificate"></i>
            <span>ICBD Certificate</span>
        </a>
        <div id="icbdcertificate" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.certificate_icbd.index') }}">All ICBD Certificate</a>
            </div>
        </div>
        
    </li>
    <!-- Divider -->
    <!-- Heading -->
    <div class="sidebar-heading">
        Payments
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
            aria-expanded="true" aria-controls="collapseFive">
            <i class="fas fa-money-bill"></i>
            <span>Fees Collection</span>
        </a>
        <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.fees.index') }}">Students List</a>
                <a class="collapse-item" href="{{ route('admin.fees.feelog') }}">Transaction List</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        HRMS
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#stuff"
            aria-expanded="true" aria-controls="stuff">
            <i class="fas fa-user-tie"></i>
            <span>Stuff</span>
        </a>
        <div id="stuff" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.stuff.index') }}">All Stuff</a>
                <a class="collapse-item" href="{{ route('admin.stuff.create') }}">Add Stuff</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <div class="sidebar-heading">
        Income and Expoance
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#branch"
            aria-expanded="true" aria-controls="branch">
            <i class="fas fa-store-alt"></i>
            <span>Branch</span>
        </a>
        <div id="branch" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.branch.index') }}">All Branch</a>
                <a class="collapse-item" href="{{ route('admin.branch.create') }}">Add Branch</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#inccategoris"
            aria-expanded="true" aria-controls="inccategoris">
            <i class="far fa-money-bill-alt"></i>
            <span>Income Categoris</span>
        </a>
        <div id="inccategoris" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.inccategoris.index') }}">All Income Categoris</a>
                <a class="collapse-item" href="{{ route('admin.inccategoris.create') }}">Add Income Categoris</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#income"
            aria-expanded="true" aria-controls="income">
            <i class="far fa-credit-card"></i>
            <span>Income</span>
        </a>
        <div id="income" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.income.index') }}">All Income</a>
                <a class="collapse-item" href="{{ route('admin.income.create') }}">Add income</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#expcategoris"
            aria-expanded="true" aria-controls="expcategoris">
            <i class="far fa-money-bill-alt"></i>
            <span>Expanse Categoris</span>
        </a>
        <div id="expcategoris" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.expcategoris.index') }}">All Categoris</a>
                <a class="collapse-item" href="{{ route('admin.expcategoris.create') }}">Add Categoris</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#expance"
            aria-expanded="true" aria-controls="expance">
            <i class="far fa-credit-card"></i>
            <span>Expanse</span>
        </a>
        <div id="expance" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.expance.index') }}">All Expanse</a>
                <a class="collapse-item" href="{{ route('admin.expance.create') }}">Add Expanse</a>
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#report"
            aria-expanded="true" aria-controls="report">
            {{-- <i class="far fa-credit-card"></i> --}}
            {{-- <i class="fas fa-file-pdf"></i> --}}
            <i class="far fa-file-pdf"></i>
            <span>Report</span>
        </a>
        <div id="report" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.income.report.index') }}">Income Report</a>
                <a class="collapse-item" href="{{ route('admin.expancere.index') }}">Expanse Report</a>
            </div>
        </div>
    </li>
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Frontend CMS
    </div>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#cms" aria-expanded="true"
            aria-controls="cms">
            <i class="fas fa-globe"></i>
            <span>CMS</span>
        </a>
        <div id="cms" class="collapse" aria-labelledby="headingCms" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('admin.slider.index') }}">Slider</a>
                <a class="collapse-item" href="{{ route('admin.story.index') }}">Success Story</a>
                <a class="collapse-item" href="{{ route('admin.review.index') }}">Review</a>
                <a class="collapse-item" href="{{ route('admin.blogcatg.index') }}">Blog Categoris</a>
                <a class="collapse-item" href="{{ route('admin.blogs.index') }}">Blog</a>
                <a class="collapse-item" href="{{ route('admin.cmsabout.index') }}">CMS About</a>
                <a class="collapse-item" href="{{ route('admin.seminor.index') }}">Seminor</a>
                <a class="collapse-item" href="{{ route('admin.seminorreg.index') }}">Seminor Registration</a>
                <a class="collapse-item" href="{{ route('admin.gallery.index') }}">Gallery</a>
                <a class="collapse-item" href="{{ route('admin.services.index') }}">Services</a>
                <a class="collapse-item" href="{{ route('admin.products.index') }}">Products</a>
                <a class="collapse-item" href="{{ route('admin.concerns.index') }}">Concerns</a>
                <a class="collapse-item" href="{{ route('admin.workflows.index') }}">Workflow</a>
                <a class="collapse-item" href="{{ route('admin.clients.index') }}">Clients</a>
                <a class="collapse-item" href="{{ route('admin.technologies.index') }}">Technologies</a>
                <a class="collapse-item" href="{{ route('admin.teams.index') }}">Team</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Heading -->
    <div class="sidebar-heading">
        Banking & Loans
    </div>
    <li class="nav-item @if (Route::currentRouteName() == 'admin.bank.loan.index' || Route::currentRouteName() == 'admin.emi.installment.index') active @endif">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#banking"
            aria-expanded="true" aria-controls="banking">
            <i class="fas fa-university"></i>
            <span>Bank Loans</span>
        </a>
        <div id="banking" class="collapse" aria-labelledby="headingBanking" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.bank.loan.index') active @endif" href="{{ route('admin.bank.loan.index') }}">All Loans</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.bank.loan.create') active @endif" href="{{ route('admin.bank.loan.create') }}">Add Loan</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.emi.installment.index') active @endif" href="{{ route('admin.emi.installment.index') }}">EMI Payments</a>
                <a class="collapse-item @if (Route::currentRouteName() == 'admin.emi.installment.create') active @endif" href="{{ route('admin.emi.installment.create') }}">Record EMI</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Heading -->
    <div class="sidebar-heading">
        Setting
    </div>


    <!-- Nav Item - Tables -->
    <li class="nav-item">
        <a class="nav-link {{ Route::currentRouteName() == 'admin.settings' ? 'active' : '' }}"
            href="{{ route('admin.settings') }}">
            <i class="fas fa-fw fa-cogs"></i>
            <span>Settings</span></a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<!-- End of Sidebar -->
