@extends('admin.app')
@section('title') {{ $pageTitle }} @endsection
@section('content')
   <!-- Page Heading -->
   <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><i class="fa fa-registered"></i> {{ $pageTitle }}</h1>
    </div>
    @include('admin.partials.flash')
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="tile">
                <h3 class="tile-title">{!! $subTitle !!}</h3>
                <form action="{{ route('admin.registration.update') }}" method="POST" role="form" enctype="multipart/form-data">
                <div class="tile-body">
                @csrf
                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <input type="hidden" name="id" value="{{$targetRegistration->id}}">
                            <input type="hidden" name="student_id" value="{{$targetRegistration->student_id}}">
                            <div class="form-group">
                                <label class="control-label" for="session_id">Compter Trade Session <span class="m-l-5 text-danger"> *</span></label>
                                <select  class="form-control @error('session_id') is-invalid @enderror" name="session_id" id="session_id">
                                <option value="">Select One</option>
                                @foreach($session as $course)
                                    <option value="{{$course->id}}" @if(old('session_id', $targetRegistration->session_id) == $course->id) {{"selected"}} @endif>{{$course->sessionName}}</option>
                                @endforeach
                                </select>
                                @error('session_id') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="ExamName">Exam Name <span class="m-l-5 text-danger"> *</span></label>
                                <select  class="form-control @error('ExamName') is-invalid @enderror" name="ExamName" id="ExamName">
                                <option value="">Select One</option>
                                    <option value="1" @if(old('ExamName', $targetRegistration->ExamName) == 1) {{"selected"}} @endif>JSC</option>
                                    <option value="2" @if(old('ExamName', $targetRegistration->ExamName) == 2) {{"selected"}} @endif>JDC</option>
                                    <option value="3" @if(old('ExamName', $targetRegistration->ExamName) == 3) {{"selected"}} @endif>SSC</option>
                                    <option value="4" @if(old('ExamName', $targetRegistration->ExamName) == 4) {{"selected"}} @endif>Dakhil</option>
                                </select>
                                @error('ExamName') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="ExamBoard">Exam Board <span class="m-l-5 text-danger"> *</span></label>
                                <select  class="form-control @error('ExamBoard') is-invalid @enderror" name="ExamBoard" id="ExamBoard">
                                    <option value="" selected="">Select One</option>
                                    <option value="1" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 1) {{"selected"}} @endif>Barisal</option>
                                    <option value="2" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 2) {{"selected"}} @endif>Chittagong</option>
                                    <option value="3" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 3) {{"selected"}} @endif>Comilla</option>
                                    <option value="4" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 4) {{"selected"}} @endif>Dhaka</option>
                                    <option value="5" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 5) {{"selected"}} @endif>Dinajpur</option>
                                    <option value="6" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 6) {{"selected"}} @endif>Jessore</option>
                                    <option value="7" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 7) {{"selected"}} @endif>Mymensingh</option>
                                    <option value="8" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 8) {{"selected"}} @endif>Rajshahi</option>
                                    <option value="9" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 9) {{"selected"}} @endif>Sylhet</option>
                                    <option value="10" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 10) {{"selected"}} @endif>Madrasah</option>
                                    <option value="11" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 11) {{"selected"}} @endif>Technical</option>
                                    <option value="12" @if(old('ExamBoard', $targetRegistration->ExamBoard) == 12) {{"selected"}} @endif>DIBS(Dhaka)</option>
                                </select>
                                @error('ExamBoard') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="ExamSession">Board Exam Session <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('ExamSession') is-invalid @enderror" type="text" name="ExamSession" id="ExamSession" value="{{ old('ExamSession', $targetRegistration->ExamSession) }}"/>
                                @error('ExamSession') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="ExamRoll">Board Exam Roll Number <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('ExamRoll') is-invalid @enderror" type="number" name="ExamRoll" id="ExamRoll" value="{{ old('ExamRoll', $targetRegistration->ExamRoll) }}"/>
                                @error('ExamRoll') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="ExamReg">Board Exam Registration Number <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('ExamReg') is-invalid @enderror" type="number" name="ExamReg" id="ExamReg" value="{{ old('ExamReg', $targetRegistration->ExamReg) }}"/>
                                @error('ExamReg') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="PassYear">Board Exam Passing Year <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('PassYear') is-invalid @enderror" type="text" name="PassYear" id="PassYear" value="{{ old('PassYear', $targetRegistration->PassYear) }}"/>
                                @error('PassYear') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="Result">Board Exam Result ( GPA ) <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('Result') is-invalid @enderror" type="text" name="Result" id="Result" value="{{ old('Result', $targetRegistration->Result) }}"/>
                                @error('Result') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="balance">Registration Fee <span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('balance') is-invalid @enderror" type="text" name="balance" id="balance" value="{{ old('balance', $targetRegistration->balance) }}"/>
                                @error('balance') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="IsActive">Registration Status <span class="m-l-5 text-danger"> *</span></label>
                                <select  class="form-control @error('IsActive') is-invalid @enderror"name="IsActive" id="IsActive">
                                    <option value="">Select one</option>
                                    <option value="1" @if(old('IsActive', $targetRegistration->IsActive) == 1) {{"selected"}} @endif>Complete</option>
                                    <option value="2" @if(old('IsActive', $targetRegistration->IsActive) == 2) {{"selected"}} @endif>Waiting For Payment</option>
                                    <option value="3" @if(old('IsActive', $targetRegistration->IsActive) == 3) {{"selected"}} @endif>Postponded</option>
                                    <option value="4" @if(old('IsActive', $targetRegistration->IsActive) == 4) {{"selected"}} @endif>Restricted</option>
                                </select>
                                @error('IsActive') {{ $message }} @enderror
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="regDate">Registration Date (MM-DD-YYYY)<span class="m-l-5 text-danger"> *</span></label>
                                <input class="form-control @error('regDate') is-invalid @enderror" type="date" name="regDate" id="regDate" value="{{ old('regDate', $targetRegistration->regDate) }}"/>
                                @error('regDate') {{ $message }} @enderror
                            </div>
                    </div>
                <div class="tile-footer">
                    <button class="btn btn-primary" type="submit" id="submitform"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update Registration</button>
                        &nbsp;&nbsp;&nbsp;
                    <a class="btn btn-secondary" href="{{ route('admin.registration.index') }}"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
                </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@push('scripts') 

@endpush